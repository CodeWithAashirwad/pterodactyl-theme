# VantixGlass — Pterodactyl Theme

A dark, responsive Pterodactyl theme foundation with:
- Glow enable/disable
- Glass enable/disable
- Custom colors and background
- Background gallery
- Login "Remember Me" UI
- Announcement management
- Admin theme settings page
- Database migrations

## Compatibility
Designed as a source theme/customization layer for Pterodactyl Panel 1.x. Pterodactyl versions can differ internally, so integrate the included Blade/CSS/JS and migration files into the exact Panel version you run rather than overwriting the entire Panel application.

## Install
1. Back up your panel.
2. Copy the `resources/views/theme` views into your Panel's resources/views tree.
3. Add `resources/css/theme.css` and `resources/js/theme.js` to the Panel's asset pipeline.
4. Apply the migration with Laravel:
   `php artisan migrate`
5. Merge the routes/controller code into your Panel customization layer.
6. Clear caches:
   `php artisan view:clear`
   `php artisan config:clear`
7. Build/rebuild the Panel frontend using the build process required by your Pterodactyl release.

## Database
The migration creates:
- `theme_settings`
- `theme_backgrounds`
- `theme_announcements`

The migration seeds a default settings row.

## Security
- Admin endpoints use Laravel auth middleware and an admin authorization gate.
- Announcement/background mutations are protected by CSRF.
- URLs are validated before being stored.
- The frontend uses textContent-style rendering for announcement content.

## Important
Do not blindly replace Pterodactyl core authentication or routing files. The Remember Me checkbox is wired to Laravel's normal `remember` credential option and should be merged into the login controller for the exact Panel release.
