<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Theme\ThemeAdminController;

Route::middleware(['web', 'auth', 'admin'])->prefix('admin/theme')->group(function () {
    Route::get('/', [ThemeAdminController::class, 'index'])->name('theme.admin');
    Route::post('/settings', [ThemeAdminController::class, 'updateSettings'])->name('theme.settings.update');

    Route::post('/backgrounds', [ThemeAdminController::class, 'storeBackground'])->name('theme.backgrounds.store');
    Route::delete('/backgrounds/{background}', [ThemeAdminController::class, 'destroyBackground'])->name('theme.backgrounds.destroy');

    Route::post('/announcements', [ThemeAdminController::class, 'storeAnnouncement'])->name('theme.announcements.store');
    Route::patch('/announcements/{announcement}', [ThemeAdminController::class, 'updateAnnouncement'])->name('theme.announcements.update');
    Route::delete('/announcements/{announcement}', [ThemeAdminController::class, 'destroyAnnouncement'])->name('theme.announcements.destroy');
});
