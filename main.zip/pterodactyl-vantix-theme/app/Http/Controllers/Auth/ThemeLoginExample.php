<?php

/*
 * Integration example only.
 * Merge this logic into the login action of your exact Pterodactyl release.
 *
 * Laravel's Auth attempt accepts a second parameter:
 * Auth::attempt($credentials, $remember);
 */

$remember = $request->boolean('remember');

// Example:
// if (Auth::attempt($credentials, $remember)) {
//     $request->session()->regenerate();
//     return redirect()->intended('/');
// }
