<?php

namespace Pterodactyl\Http\Controllers\Theme;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Pterodactyl\Models\ThemeSetting;
use Pterodactyl\Models\ThemeBackground;
use Pterodactyl\Models\ThemeAnnouncement;

class ThemeAdminController extends Controller
{
    public function index()
    {
        return view('theme.admin', [
            'settings' => ThemeSetting::current(),
            'backgrounds' => ThemeBackground::latest()->get(),
            'announcements' => ThemeAnnouncement::latest()->get(),
        ]);
    }

    public function updateSettings(Request $request)
    {
        $data = $request->validate([
            'theme_name' => 'required|string|max:120',
            'primary_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'accent_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'glow_enabled' => 'nullable|boolean',
            'glow_intensity' => 'required|integer|min:0|max:100',
            'glass_enabled' => 'nullable|boolean',
            'glass_opacity' => 'required|integer|min:0|max:100',
            'glass_blur' => 'required|integer|min:0|max:50',
            'background_url' => 'nullable|url|max:2048',
            'background_overlay' => 'required|integer|min:0|max:100',
            'login_logo_url' => 'nullable|url|max:2048',
            'login_title' => 'required|string|max:120',
        ]);

        $data['glow_enabled'] = $request->boolean('glow_enabled');
        $data['glass_enabled'] = $request->boolean('glass_enabled');

        ThemeSetting::current()->update($data);

        return back()->with('success', 'Theme settings saved.');
    }

    public function storeBackground(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:120',
            'url' => 'required|url|max:2048',
        ]);

        ThemeBackground::create($data);

        return back()->with('success', 'Background added.');
    }

    public function destroyBackground(ThemeBackground $background)
    {
        $background->delete();
        return back()->with('success', 'Background removed.');
    }

    public function storeAnnouncement(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:160',
            'message' => 'required|string|max:10000',
            'type' => 'required|in:info,success,warning,danger',
            'enabled' => 'nullable|boolean',
            'expires_at' => 'nullable|date',
        ]);

        $data['enabled'] = $request->boolean('enabled');
        ThemeAnnouncement::create($data);

        return back()->with('success', 'Announcement created.');
    }

    public function updateAnnouncement(Request $request, ThemeAnnouncement $announcement)
    {
        $data = $request->validate([
            'title' => 'required|string|max:160',
            'message' => 'required|string|max:10000',
            'type' => 'required|in:info,success,warning,danger',
            'enabled' => 'nullable|boolean',
            'expires_at' => 'nullable|date',
        ]);

        $data['enabled'] = $request->boolean('enabled');
        $announcement->update($data);

        return back()->with('success', 'Announcement updated.');
    }

    public function destroyAnnouncement(ThemeAnnouncement $announcement)
    {
        $announcement->delete();
        return back()->with('success', 'Announcement removed.');
    }
}
