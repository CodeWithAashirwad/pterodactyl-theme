<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Model;

class ThemeSetting extends Model
{
    protected $fillable = [
        'theme_name', 'primary_color', 'accent_color',
        'glow_enabled', 'glow_intensity',
        'glass_enabled', 'glass_opacity', 'glass_blur',
        'background_url', 'background_overlay',
        'login_logo_url', 'login_title',
    ];

    protected $casts = [
        'glow_enabled' => 'boolean',
        'glass_enabled' => 'boolean',
    ];

    public static function current(): self
    {
        return static::query()->firstOrCreate([], [
            'theme_name' => 'VantixGlass',
            'primary_color' => '#7c3aed',
            'accent_color' => '#a855f7',
        ]);
    }
}
