<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Model;

class ThemeAnnouncement extends Model
{
    protected $fillable = ['title', 'message', 'type', 'enabled', 'expires_at'];
    protected $casts = [
        'enabled' => 'boolean',
        'expires_at' => 'datetime',
    ];

    public function scopeVisible($query)
    {
        return $query->where('enabled', true)
            ->where(function ($q) {
                $q->whereNull('expires_at')->orWhere('expires_at', '>', now());
            });
    }
}
