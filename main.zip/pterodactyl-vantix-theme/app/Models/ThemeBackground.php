<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Model;

class ThemeBackground extends Model
{
    protected $fillable = ['name', 'url', 'enabled'];
    protected $casts = ['enabled' => 'boolean'];
}
