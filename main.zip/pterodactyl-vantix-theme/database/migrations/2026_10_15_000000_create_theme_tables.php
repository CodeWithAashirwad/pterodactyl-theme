<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('theme_settings', function (Blueprint $table) {
            $table->id();
            $table->string('theme_name')->default('VantixGlass');
            $table->string('primary_color', 20)->default('#7c3aed');
            $table->string('accent_color', 20)->default('#a855f7');
            $table->boolean('glow_enabled')->default(true);
            $table->unsignedTinyInteger('glow_intensity')->default(55);
            $table->boolean('glass_enabled')->default(true);
            $table->unsignedTinyInteger('glass_opacity')->default(78);
            $table->unsignedTinyInteger('glass_blur')->default(18);
            $table->string('background_url', 2048)->nullable();
            $table->unsignedTinyInteger('background_overlay')->default(55);
            $table->string('login_logo_url', 2048)->nullable();
            $table->string('login_title', 120)->default('Welcome back');
            $table->timestamps();
        });

        Schema::create('theme_backgrounds', function (Blueprint $table) {
            $table->id();
            $table->string('name', 120);
            $table->string('url', 2048);
            $table->boolean('enabled')->default(true);
            $table->timestamps();
        });

        Schema::create('theme_announcements', function (Blueprint $table) {
            $table->id();
            $table->string('title', 160);
            $table->text('message');
            $table->enum('type', ['info', 'success', 'warning', 'danger'])->default('info');
            $table->boolean('enabled')->default(true);
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
        });

        DB::table('theme_settings')->insert([
            'theme_name' => 'VantixGlass',
            'primary_color' => '#7c3aed',
            'accent_color' => '#a855f7',
            'glow_enabled' => true,
            'glow_intensity' => 55,
            'glass_enabled' => true,
            'glass_opacity' => 78,
            'glass_blur' => 18,
            'background_overlay' => 55,
            'login_title' => 'Welcome back',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('theme_announcements');
        Schema::dropIfExists('theme_backgrounds');
        Schema::dropIfExists('theme_settings');
    }
};
