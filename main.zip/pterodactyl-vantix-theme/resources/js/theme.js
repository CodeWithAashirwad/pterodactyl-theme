(() => {
    const root = document.documentElement;
    const config = window.PTERO_THEME || {};

    const setVar = (name, value) => root.style.setProperty(name, value);

    if (config.primaryColor) setVar('--theme-primary', config.primaryColor);
    if (config.accentColor) setVar('--theme-accent', config.accentColor);
    if (config.backgroundUrl) setVar('--theme-background-image', `url("${config.backgroundUrl}")`);
    if (typeof config.backgroundOverlay === 'number') {
        setVar('--theme-background-overlay', String(config.backgroundOverlay / 100));
    }
    if (typeof config.glassBlur === 'number') setVar('--theme-glass-blur', `${config.glassBlur}px`);

    document.body.classList.toggle('theme-glow', !!config.glowEnabled);
    document.body.classList.toggle('theme-glass', !!config.glassEnabled);

    const intensity = Math.max(0, Math.min(100, Number(config.glowIntensity ?? 55)));
    setVar('--theme-glow', `0 0 ${Math.round(10 + intensity * .45)}px color-mix(in srgb, var(--theme-primary), transparent 45%)`);

    document.querySelectorAll('[data-theme-bg]').forEach((button) => {
        button.addEventListener('click', () => {
            const url = button.getAttribute('data-theme-bg');
            if (url) {
                setVar('--theme-background-image', `url("${url}")`);
            }
        });
    });
})();
