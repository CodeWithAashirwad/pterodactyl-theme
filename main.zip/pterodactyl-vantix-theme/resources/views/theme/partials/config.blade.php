@php
    $theme = \Pterodactyl\Models\ThemeSetting::current();
@endphp
<script>
window.PTERO_THEME = @json([
    'primaryColor' => $theme->primary_color,
    'accentColor' => $theme->accent_color,
    'glowEnabled' => $theme->glow_enabled,
    'glowIntensity' => $theme->glow_intensity,
    'glassEnabled' => $theme->glass_enabled,
    'glassOpacity' => $theme->glass_opacity,
    'glassBlur' => $theme->glass_blur,
    'backgroundUrl' => $theme->background_url,
    'backgroundOverlay' => $theme->background_overlay,
]);
</script>
