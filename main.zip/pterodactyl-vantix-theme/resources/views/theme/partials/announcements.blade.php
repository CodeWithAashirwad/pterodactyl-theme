@php
    $announcements = \Pterodactyl\Models\ThemeAnnouncement::visible()->latest()->get();
@endphp

@if($announcements->isNotEmpty())
    <div class="theme-announcements" aria-label="Announcements">
        @foreach($announcements as $announcement)
            <article class="theme-card theme-announcement {{ $announcement->type }}">
                <strong>{{ $announcement->title }}</strong>
                <div>{{ $announcement->message }}</div>
                <button type="button" aria-label="Dismiss announcement"
                    onclick="this.closest('article').remove()"
                    style="margin-top:8px">Dismiss</button>
            </article>
        @endforeach
    </div>
@endif
