{{-- Insert this inside the existing Pterodactyl login form. --}}
<div style="display:flex;align-items:center;gap:8px;margin:12px 0">
    <input id="remember" type="checkbox" name="remember" value="1">
    <label for="remember">Remember me</label>
</div>
