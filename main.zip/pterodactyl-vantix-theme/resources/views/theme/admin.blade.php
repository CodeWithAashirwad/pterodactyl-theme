@extends('layouts.admin')

@section('title', 'Theme Settings')

@section('content')
<div class="theme-shell">
    <div style="padding:24px">
        @if(session('success'))
            <div class="theme-card theme-admin-card">{{ session('success') }}</div>
        @endif

        <h1 style="font-size:28px;font-weight:800;margin-bottom:20px">Theme Settings</h1>

        <form method="POST" action="{{ route('theme.settings.update') }}" class="theme-admin-grid">
            @csrf
            <section class="theme-card theme-admin-card">
                <h2>General</h2>
                <label class="theme-field">Theme Name
                    <input name="theme_name" value="{{ $settings->theme_name }}" maxlength="120">
                </label>
                <label class="theme-field">Primary Color
                    <input type="color" name="primary_color" value="{{ $settings->primary_color }}">
                </label>
                <label class="theme-field">Accent Color
                    <input type="color" name="accent_color" value="{{ $settings->accent_color }}">
                </label>
            </section>

            <section class="theme-card theme-admin-card">
                <h2>Effects</h2>
                <label class="theme-switch"><input type="checkbox" name="glow_enabled" value="1" @checked($settings->glow_enabled)> Enable Glow</label>
                <label class="theme-field">Glow Intensity
                    <input type="range" name="glow_intensity" min="0" max="100" value="{{ $settings->glow_intensity }}">
                </label>
                <label class="theme-switch"><input type="checkbox" name="glass_enabled" value="1" @checked($settings->glass_enabled)> Enable Glass</label>
                <label class="theme-field">Glass Opacity
                    <input type="range" name="glass_opacity" min="0" max="100" value="{{ $settings->glass_opacity }}">
                </label>
                <label class="theme-field">Glass Blur
                    <input type="range" name="glass_blur" min="0" max="50" value="{{ $settings->glass_blur }}">
                </label>
            </section>

            <section class="theme-card theme-admin-card">
                <h2>Background & Login</h2>
                <label class="theme-field">Background URL
                    <input type="url" name="background_url" value="{{ $settings->background_url }}" placeholder="https://...">
                </label>
                <label class="theme-field">Overlay
                    <input type="range" name="background_overlay" min="0" max="100" value="{{ $settings->background_overlay }}">
                </label>
                <label class="theme-field">Login Logo URL
                    <input type="url" name="login_logo_url" value="{{ $settings->login_logo_url }}" placeholder="https://...">
                </label>
                <label class="theme-field">Login Title
                    <input name="login_title" value="{{ $settings->login_title }}" maxlength="120">
                </label>
            </section>

            <section class="theme-card theme-admin-card" style="grid-column:1/-1">
                <button class="theme-button" type="submit">Save Theme Settings</button>
            </section>
        </form>

        <section class="theme-card theme-admin-card" style="margin-top:20px">
            <h2>Background Gallery</h2>
            <form method="POST" action="{{ route('theme.backgrounds.store') }}">
                @csrf
                <div class="theme-admin-grid">
                    <label class="theme-field">Name<input name="name" required></label>
                    <label class="theme-field">Image URL<input type="url" name="url" required></label>
                </div>
                <button class="theme-button">Add Background</button>
            </form>

            <div class="theme-gallery" style="margin-top:18px">
                @foreach($backgrounds as $background)
                    <div class="theme-gallery-item">
                        <img src="{{ $background->url }}" alt="{{ $background->name }}">
                        <div style="padding:10px">
                            <strong>{{ $background->name }}</strong>
                            <button type="button" class="theme-button" style="margin-top:8px;width:100%"
                                data-theme-bg="{{ $background->url }}">Preview</button>
                            <form method="POST" action="{{ route('theme.backgrounds.destroy', $background) }}" style="margin-top:8px">
                                @csrf @method('DELETE')
                                <button class="theme-button" type="submit" style="width:100%">Delete</button>
                            </form>
                        </div>
                    </div>
                @endforeach
            </div>
        </section>

        <section class="theme-card theme-admin-card" style="margin-top:20px">
            <h2>Announcements</h2>
            <form method="POST" action="{{ route('theme.announcements.store') }}">
                @csrf
                <div class="theme-admin-grid">
                    <label class="theme-field">Title<input name="title" maxlength="160" required></label>
                    <label class="theme-field">Type
                        <select name="type">
                            <option value="info">Info</option>
                            <option value="success">Success</option>
                            <option value="warning">Warning</option>
                            <option value="danger">Danger</option>
                        </select>
                    </label>
                    <label class="theme-field">Expires At<input type="datetime-local" name="expires_at"></label>
                    <label class="theme-switch"><input type="checkbox" name="enabled" value="1" checked> Enabled</label>
                </div>
                <label class="theme-field">Message<textarea name="message" rows="4" required></textarea></label>
                <button class="theme-button">Create Announcement</button>
            </form>

            <div style="margin-top:18px">
                @foreach($announcements as $announcement)
                    <div class="theme-card theme-announcement {{ $announcement->type }}">
                        <strong>{{ $announcement->title }}</strong>
                        <p>{{ $announcement->message }}</p>
                        <small>{{ $announcement->enabled ? 'Enabled' : 'Disabled' }}</small>
                        <form method="POST" action="{{ route('theme.announcements.destroy', $announcement) }}" style="margin-top:8px">
                            @csrf @method('DELETE')
                            <button class="theme-button" type="submit">Delete</button>
                        </form>
                    </div>
                @endforeach
            </div>
        </section>
    </div>
</div>
@endsection
